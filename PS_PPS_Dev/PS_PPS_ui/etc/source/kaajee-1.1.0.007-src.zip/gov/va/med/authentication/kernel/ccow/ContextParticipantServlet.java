package gov.va.med.authentication.kernel.ccow;

/**
 *
 * File:        $Id$
 * @author:     $Author$
 * @version     $Revision$ $DateTime$
 * Changelist:  $Change$
 *
 * Created:     12/01/00 (1.December.2000)
 * Package:     SDK Web Example Servlet
 * Description:  
 *
 * (c) Copyright Sentillion, Inc., 2000,2001,2002. All rights reserved.
 *     Reproduction, adaptation, or translation without prior written
 *     permission is prohibited except as allowed under the copyright
 *     permission.
 *
 */

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author VHIT Security and Other Common Services (S&OCS)
 * @version 1.1.0.007
 */
public class ContextParticipantServlet extends HttpServlet
{
	
	public void doGet (HttpServletRequest req,
					   HttpServletResponse res)
		throws ServletException, IOException
	{		
		ContextChangesMessage msg = new ContextChangesMessage(req, res);
		ContextParticipant participant = new ContextParticipant(msg);
		participant.respond();	
	}	
}